# CA2-2020274
 CCT College -  MSc Data Analytics FT Feb 23 - CA2 Repository for CA2 
 Author: Clarissa Cardoso
 Student ID: 2020274
 


Abstract
This report presents and overview of determined variables to investigate the number of new building permits over the period from 1977 to 2022 for the Irish State and followed by a broader analysis to compare Ireland with four other countries in the Euro Zone in terms of employment in construction, GDP per capita and investment in dwellings. Several techniques of data exploration, cleaning, preparation and visualisation were used to find the adequate statistical distribution patterns for application of Hypothesis Testing and Machine Learning models for the availability of construction workers to provide insights of future increase in workforce demands in the sector the scenario of construction considering Ireland as a base point.
